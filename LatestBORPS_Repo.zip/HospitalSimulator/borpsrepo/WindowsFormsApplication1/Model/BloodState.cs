﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class BloodState
    {
        int state_id;
        string state;
        public BloodState(int state_id, string state) 
        {
            this.state_id = state_id;
            this.state = state;
        }

        public void setState() 
        {

        }

        public void setProcessing()
        {

        }

        public string getState()
        {
            String bob = "";
            return bob;
        }

        public string getProcessing()
        {
            String process = "";
            return process;
        }
    }
}
