﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
    
namespace WindowsFormsApplication1.Model
{
    class DbConnect
    {
        public NpgsqlConnection conn;

        public DbConnect()
        {
            // Connect to a PostgreSQL database
            conn = new NpgsqlConnection("Server=reddwarf.cs.rit.edu;" +
                "User Id=p32004a;" +
                "Password=phook4eihei3Eiqu3tie;" +
                "Database=p32004a;" +
                "Port=5432;");
            conn.Open();
            Console.WriteLine("HELLO");
        }

        public int hospitalEntries()
        {
            int count = 0;
            NpgsqlCommand command1 = new NpgsqlCommand("COUNT(hospital)", conn);

            return count;
        }

        public String getHospitalFromDatabase()
        {
            String s = "";
            NpgsqlCommand command1 = new NpgsqlCommand("SELECT x FROM hospital", conn);
            NpgsqlCommand command2 = new NpgsqlCommand("SELECT y FROM hospital", conn);
            NpgsqlCommand command3 = new NpgsqlCommand("SELECT name FROM hospital", conn);
            NpgsqlCommand command4 = new NpgsqlCommand("SELECT id FROM hospital", conn);
            NpgsqlDataReader dr1 = command1.ExecuteReader();
            NpgsqlDataReader dr2 = command2.ExecuteReader();
            NpgsqlDataReader dr3 = command3.ExecuteReader();
            NpgsqlDataReader dr4 = command4.ExecuteReader();
            
            return s;
        }

        public void closeConnection()
        {
            conn.Close();
        }

        public NpgsqlConnection getConn()
        {
            return conn;
        }

        public void printHospitalToTerminal()
        {
            Console.Write("CONNECTION {0}\n", conn.State);
            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand("SELECT * FROM hospital", conn);

            // Execute the query and obtain a result set
            NpgsqlDataReader dr = command.ExecuteReader();

            // Output rows
            while (dr.Read())
                Console.Write("{0}\t{1}\t{2}\n", dr[0], dr[1], dr[2]);

            conn.Close();
        }
    }
}
