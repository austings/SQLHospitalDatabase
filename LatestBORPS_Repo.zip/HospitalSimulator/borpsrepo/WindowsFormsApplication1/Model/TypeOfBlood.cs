﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class TypeOfBlood
    {
        Blood blood;
        public TypeOfBlood(Blood blood)
        {
            this.blood = blood;
        }

        public void setBloodType()
        {

        }

        public string getBloodType()
        {
            String strg = "";
            return strg;
        }
    }
}
