﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Properties;

namespace WindowsFormsApplication1.Model
{
    class Simulation
    {
        private int randomRangeStart = 1;
        private int randomRangeEnd = 4;
        private int timeWaitSim = 1500;
        private int speed = 1;
        private bool pauseSim = true;
        private static SimThread simThread;
        private static Simulation sim = new Simulation();
        private Thread t;
        public static Form1 form1;

        private Simulation()
        {
            simThread = new SimThread();
        }

        /**
         * DO NOT USE THIS EVER!!!! ONLY NEEDED ONCE IN STARTUP
         */
        public static Simulation getSimulation(Form1 form2)
        {
            form1 = form2;
            if (!simThread.isStarted())
            {
                Thread t = new Thread(new ThreadStart(simThread.RunMe));
                t.Start();
            }
            return sim;
        }

        public static Simulation getSimulation()
        {
            if (!simThread.isStarted())
            {
                Thread t = new Thread(new ThreadStart(simThread.RunMe));
                t.Start(); 
            }
            return sim;
        }

        public int timeWait()
        {
            return timeWaitSim;
        }

        public int getSpeed(){
            return timeWaitSim*speed;
        }

        public bool isPaused()
        {
            return pauseSim;
        }

        public void pause()
        {
            pauseSim = true;
        }

        public void setSpeedOne()
        {
            pauseSim = false;
            speed = 1;
        }

        public void setSpeedTwo()
        {
            pauseSim = false;
            speed = 2;
        }

        public void kill()
        {
            if (simThread != null)
            {
                simThread.kill();
            }
        }

        public void simulateCycle()
        {
            ArrayList hospitals = Hospital.get_hospital_list();
            Random rnd = new Random();
            int bloodUse = 0;
            int bloodDonated = 0;
            String output = "";

            //using blood
            for(int i = 0; i < hospitals.Count; i++) {
                float percent = rnd.Next(randomRangeStart, randomRangeEnd);
                ArrayList bloodList = Blood.get_hospital_blood_NOT_used(((Hospital)hospitals[i]).getId());
                float amount = bloodList.Count/percent;
                for (int a = 0; a < bloodList.Count; a++)
                {
                    bloodUse++;
                    ((Blood)bloodList[a]).update_blood_state(true);
                }
            }
            output += "Change blood states of [" + bloodUse + "] blood rows in Blood Table \n";

            //adding blood
            for (int i = 0; i < hospitals.Count; i++)
            {
                int percent = rnd.Next(randomRangeStart, randomRangeEnd);
                for (int a = 0; a < percent; a++)
                {
                    int randType = rnd.Next(1,Blood.bloodType.Count())-1;
                    Blood.insert_blood(((Hospital)hospitals[i]).getId(), Blood.bloodType[randType], false);
                    bloodDonated++;
                }
            }

            output += "Inserted [" + bloodUse + "] new blood rows. \n";

            if (!form1.killed)
            {
                string newText = "" + Hospital.getCount();
                form1.Invoke((MethodInvoker)delegate
                {
                    form1.Label2.Text = newText;
                    form1.Label4.Text = "" + bloodUse;
                    form1.Label6.Text = "" + bloodDonated;
                    string text = form1.textBox1.Text;
                    form1.textBox1.Text = text + output;
                });
            }
        }
    }
}
