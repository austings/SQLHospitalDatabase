using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using WindowsFormsApplication1.Model;
using System.Collections;

namespace WindowsFormsApplication1
{
    class Blood
    {
        private int hospital_id;
        private int blood_id;
        private string blood_type;
        private bool blood_state;

        public static readonly string[] bloodType = new string[5] { "A+", "A-", "AB+", "O+", "B-"};

        private static DbConnect dbConnect = new DbConnect();

        public Blood(int hospital_id, int blood_id, string blood_type, bool blood_state)
        {
            this.hospital_id = hospital_id;
            this.blood_id = blood_id;
            this.blood_type = blood_type;
            this.blood_state = blood_state;
        }

        public int getHospitalID()
        {
            return hospital_id;
        }

        public int getBloodID()
        {
            return blood_id;
        }

        public string getBloodType()
        {
            return blood_type;
        }

        public Boolean getBloodState()
        {
            return blood_state;
        }

        /*
         * Update the current bloods state
         * */
        public void update_blood_state(bool state)
        {
            DbConnect db = new DbConnect();
            // Update the blood state
            String s = "UPDATE blood SET blood_state = " + state + " where blood_id = " + blood_id + ";";
            NpgsqlCommand update = new NpgsqlCommand(s, db.getConn());
            update.ExecuteNonQuery();
            db.closeConnection();
        }

        /*
         * Update the current hospital id of the object and in db.
         * */
        public void update_hospital_id(int hospital_id)
        {
            // Update the hospital id related to blood
            NpgsqlCommand update = new NpgsqlCommand("UPDATE blood SET hospital_id = " + hospital_id +
                " where blood_id = " + blood_id + ";", dbConnect.getConn());
            update.ExecuteReader();
        }


        /*
         * Returns a complete list of Blood objects for a specific hospital
         * */
        public static ArrayList get_hospital_blood(int hospital_id)
        {
            DbConnect dbConnect = new DbConnect();
            ArrayList list = new ArrayList();

            // Get the blood related to the hospital
            NpgsqlCommand blood = new NpgsqlCommand("SELECT * FORM blood WHERE id = " + hospital_id + ";", dbConnect.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dt = blood.ExecuteReader();

            // Output rows
            while (dt.Read())
            {
                list.Add(new Blood(Convert.ToInt32(dt[0]),  //hospital id
                    Convert.ToInt32(dt[1]),                 //blood id
                    Convert.ToString(dt[2]),                //blood type
                    Convert.ToBoolean(dt[3])));             //blood state
            }
            dbConnect.closeConnection();
            return list;
        }

        /*
         * Returns a complete list of Blood objects for a specific hospital that have not been used
         * */
        public static ArrayList get_hospital_blood_NOT_used(int hospital_id)
        {
            DbConnect db = new DbConnect();
            ArrayList list = new ArrayList();
            String s = "SELECT * FROM blood WHERE hospital_id = " + hospital_id + " AND blood_state = false;";
            // Get the blood related to the hospital
            NpgsqlCommand blood = new NpgsqlCommand(s, db.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dt = blood.ExecuteReader();

            // Output rows
            while (dt.Read())
            {
                list.Add(new Blood(Convert.ToInt32(dt[0]),  //hospital id
                    Convert.ToInt32(dt[1]),                 //blood id
                    Convert.ToString(dt[2]),                //blood type
                    Convert.ToBoolean(dt[3])));             //blood state
            }
            db.closeConnection();
            return list;
        }

        /*
         * Returns a complete list of Blood objects for a given type.
         * */
        public static ArrayList get_blood_from_type(string blood_type)
        {
            DbConnect db = new DbConnect();
            ArrayList list = new ArrayList();

            // Get the blood depending on the type
            NpgsqlCommand blood = new NpgsqlCommand("SELECT * FORM blood WHERE blood_type = '" + blood_type + "';", db.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dt = blood.ExecuteReader();

            // Output rows
            while (dt.Read())
            {
                list.Add(new Blood(Convert.ToInt32(dt[0]),  //hospital id
                    Convert.ToInt32(dt[1]),                 //blood id
                    Convert.ToString(dt[2]),                //blood type
                    Convert.ToBoolean(dt[3])));             //blood state
            }
            db.closeConnection();
            return list;
        }

        /*
         * Returns a complete list of Blood objects for the whole table
         * */
        public static ArrayList get_blood_list()
        {
            ArrayList list = new ArrayList();
            DbConnect dbConnect = new DbConnect();
            // Get the blood table
            NpgsqlCommand blood_table = new NpgsqlCommand("SELECT * FROM blood;", dbConnect.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dt = blood_table.ExecuteReader();

            // Output rows
            while (dt.Read())
            {
                list.Add(new Blood(Convert.ToInt32(dt[0]),  //hospital id
                    Convert.ToInt32(dt[1]),                 //blood id
                    Convert.ToString(dt[2]),                //blood type
                    Convert.ToBoolean(dt[3])));             //blood state
            }

            dbConnect.closeConnection();
            return list;
        }


        /*
         * Creates a new Blood object and returns it as well as inserting into DB
         * */
        public static Blood insert_blood(int hospital_id, string blood_type, bool blood_state)
        {
            DbConnect db = new DbConnect();
            // Insert blood into table
            string s = "insert into blood (hospital_id,blood_type,blood_state) values(" +
                hospital_id + ",'" +
                blood_type + "'," +
                blood_state + ") returning blood_id;";
            NpgsqlCommand add = new NpgsqlCommand(s, db.getConn());
            NpgsqlDataReader dt = add.ExecuteReader();
            int returnVal = 0;
            while (dt.Read())
            {
                returnVal = Convert.ToInt32(dt[0]);
            }
            db.closeConnection();
            return new Blood(hospital_id, returnVal, blood_type, blood_state);
        }
    }
}
