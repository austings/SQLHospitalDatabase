﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class BloodRequest
    {
        int id_request;
        Array[] request;

        public BloodRequest(int id_request) 
        {
            this.id_request = id_request;
        }

        public void setRequestFilled()
        {

        }

        public Array[] getRequestInformation()
        {
            return request;
        }
    }
}
