﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Model
{
    class SimThread
    {
        Simulation sim;
        private bool isStartedSim = false;
        private bool runMe = true;

        public SimThread()
        {
        }

        public void RunMe()
        {
            sim = Simulation.getSimulation();
            isStartedSim = true;
            while (runMe)
            {
                Console.WriteLine("RunMe Called");
                if (!sim.isPaused())
                {
                    sim.simulateCycle();
                }
                Thread.Sleep(sim.getSpeed());
            }
        }

        public bool isStarted()
        {
            return isStartedSim;
        }

        public void kill()
        {
            runMe = false;
        }
    }
}
