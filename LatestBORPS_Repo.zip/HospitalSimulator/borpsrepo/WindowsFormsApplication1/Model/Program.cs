﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Model;
using Npgsql;

namespace WindowsFormsApplication1
{
    static class Program
    {

        public static List<Hospital> createHospitals()
        {
            DbConnect d = new DbConnect();
            NpgsqlConnection conn = d.getConn();
            NpgsqlCommand command1 = new NpgsqlCommand("SELECT * FROM hospital", conn);
            //NpgsqlCommand command2 = new NpgsqlCommand("SELECT y FROM hospital", conn);
            //NpgsqlCommand command3 = new NpgsqlCommand("SELECT name FROM hospital", conn);
            //NpgsqlCommand command4 = new NpgsqlCommand("SELECT id FROM hospital", conn);
            NpgsqlDataReader dr1 = command1.ExecuteReader();
            //NpgsqlDataReader dr2 = command2.ExecuteReader();
            //NpgsqlDataReader dr3 = command3.ExecuteReader();
            //NpgsqlDataReader dr4 = command4.ExecuteReader();
            // Output rows

            List<Hospital> hospitals = new List<Hospital>();
            while (dr1.Read())
            {
                Console.Write("{0}\t{1}\t{2}\t{3}\n", dr1[0], dr1[1], dr1[2], dr1[3]);

                hospitals.Add(new Hospital(Convert.ToString(dr1[2]), Convert.ToInt32(dr1[3]),
                    Convert.ToInt32(dr1[0]), Convert.ToInt32(dr1[1])));
            }
            d.closeConnection();

            
            //Get hospitals text file. Need to overload to split by newline
            //String[] text = Properties.Resources.list.Split(
            //    new string[] { Environment.NewLine }, StringSplitOptions.None); ;

            //create a list of hospitals

            //iterate through each line, creating a new hospital in the list for each.
            //for (int i = 0; i <text.Length;i++)
            //{
                //String[] hospital = text[i].Split(',');
                //hospitals.Add(new Hospital(hospital[1], Convert.ToInt32(hospital[0]),
                //    Convert.ToInt32(hospital[2]), Convert.ToInt32(hospital[3]), new Blood()));
            //}
            return hospitals;
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
