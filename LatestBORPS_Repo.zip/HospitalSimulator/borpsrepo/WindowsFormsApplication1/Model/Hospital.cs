﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApplication1.Model;
using Npgsql;

namespace WindowsFormsApplication1
{
    public class Hospital
    {
        private String name = "";
        private int x;
        private int y;
        private int id;

        public Hospital()
        {}

        public Hospital(String name, int ID, int x, int y)
        {
            this.name = name;
            this.x = x;
            this.y = y;
            this.id = ID;
            drawOnBoard();
        }

        public string getName()
        {
            return name;
        }

        public int getId()
        {
            return id;
        }

        public int getX()
        {
            return x;
        }

        public int getY()
        {
            return y;
        }

        /*
         * Returns a complete list of Hospital objects for the whole table
         * */
        public static ArrayList get_hospital_list()
        {
            ArrayList list = new ArrayList();
            DbConnect db = new DbConnect();
            // Get the blood table
            NpgsqlCommand hospitalTable = new NpgsqlCommand("SELECT * FROM hospital;", db.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dr1 = hospitalTable.ExecuteReader();

            // Output rows
            while (dr1.Read())
            {
                list.Add(new Hospital(Convert.ToString(dr1[2]), Convert.ToInt32(dr1[3]),
                    Convert.ToInt32(dr1[0]), Convert.ToInt32(dr1[1])));
            }
            db.closeConnection();
            return list;
        }

        public static int getCount()
        {
            DbConnect db = new DbConnect();
            // Get the blood table
            NpgsqlCommand hospitalTable = new NpgsqlCommand("SELECT COUNT(*) FROM hospital;", db.getConn());

            // Execute the query and obtain a result set
            NpgsqlDataReader dr1 = hospitalTable.ExecuteReader();
            int count = 0;
            // Output rows
            while (dr1.Read())
            {
                count = Convert.ToInt32(dr1[0]);
            }
            db.closeConnection();
            return count;
        }

        public void drawOnBoard()
        {
            
        }
    }
}
