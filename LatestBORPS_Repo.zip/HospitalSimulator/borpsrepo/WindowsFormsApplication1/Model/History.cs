﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class History
    {
        int history_id;
        Array[] h;
        public History(int history_id)
        {
            this.history_id = history_id;
        }

        public Array[] getTransactionInformation()
        {
            return h;
        }
    }
}
