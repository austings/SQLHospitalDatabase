using System;
using System.Collections.Generic;
using System.Timers;

namespace WindowsFormsApplication1
{
    class SimulationTest
    {
        public static void Main()
        {
            // Size needs to be set to be equivilent to number of hospitals.
            int[] values = new int[6];
            Random rnd = new Random();
            for(int i = 0; i < values.Length; i++) 
            {
                values[i] = rnd.Next(0, 100);
            }
            Console.WriteLine(string.Join(", ", values));
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Elapsed += (sender, e) => EventTick(sender, e, values);
            timer.Interval = 1000;
            timer.Enabled = true;

            Console.WriteLine("Press q to end simulation.");
            while(Console.Read() != 'q');
        }

        private static void EventTick(object source, ElapsedEventArgs e, int[] upValues)
        {
            int nValues = new int[6];
            Random nrnd = new Random();
            for(int i = 0; i < nValues.Length; i++) 
            {
                nValues[i] = nrnd.Next(-5, 5);
                values[i] = values[i] + nValues[i];
            }
            // No values currently stored. Will need to alter to allow for storing of quantity of blood.
            Console.WriteLine(string.Join(", ", values));
        }
    }
}