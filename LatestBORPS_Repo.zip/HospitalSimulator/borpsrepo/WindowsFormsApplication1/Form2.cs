﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Model;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public WindowsFormsApplication1.Hospital h;

        public Form2(Hospital h)
        {
            this.h = h;
            InitializeComponent();
            drawMe();
        }

        public void drawMe()
        {
            label1.Text = h.getName() + " Hospital";
            label2.Text = "("+h.getX() + ", "+ h.getY() +")";
        }

        public void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
