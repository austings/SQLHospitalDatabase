﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using WindowsFormsApplication1.Model;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Simulation sim;
        public List<Hospital> h;
        public bool killed = false;

        public Form1()
        {
            InitializeComponent();
            sim = Simulation.getSimulation(this);
        }

        private void SplitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SplitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public void DrawPanel_Paint(object sender, PaintEventArgs e)
        {

            //get every hospital to draw
            h= Program.createHospitals();

            //to see if we've already built a road
            List<Point> compared = new List<Point>();

            //setup graphics engine
            Graphics graphics = ((Panel)sender).CreateGraphics();

            //loop through each hospital
            foreach (Hospital hospital in h)
            {
                //create a button for the hospital
                //design button
                Button b = new Button();
                b.Click += new EventHandler(hospitalClick);
                b.Image= (Properties.Resources.hospital);
                Size size = new Size(100, 50);
                b.Size = size;
                Point point2 = new Point(hospital.getX(), hospital.getY());
                b.Location = point2;
                String text = hospital.getName() + " Hospital";
                b.Font = new Font("Georgia", 8);
                b.Text = text;

                ((Panel)sender).Controls.Add(b);

                //draw roads between close hospitals
                // Distance =√((x2−x1)^2+(y2−y1)^2)
                foreach (Hospital compare in h)
                {
                    //first see if we've already built a road
                    Point point1 = new Point(compare.getX()+ 50, compare.getY()+25);
                    point2 = new Point(hospital.getX() + 50, hospital.getY()+25);
                    if (IfRoadDoesntExist(point1,point2,compared))
                    {
                        //calculate distance between hospital
                        double difx = compare.getX() - hospital.getX();
                        double dify = compare.getY() - hospital.getY();
                        double distance = Math.Sqrt((Math.Pow(difx, 2) + Math.Pow(dify, 2)));
                        Console.Write(distance);
                        //draw road if less than 250
                        if (distance <= 250.00)
                        {
                            //black road
                            Pen pen = new Pen(System.Drawing.Color.Black, 10);
                            graphics.DrawLine(pen, point1, point2);
                            
                            //yellow lines
                            Pen whitepen = new Pen(System.Drawing.Color.Yellow, 1);
                            float[] dashValues = { 2, 4, 6 };
                            whitepen.DashPattern = dashValues;
                            graphics.DrawLine(whitepen, point1, point2);
                            compared.Add(point1);
                            compared.Add(point2);
                        }

                    }
                }
            }
        }

        /**
         * When drawing roads I check each one twice, so ensure I don't draw the road twice
         * points- the hospitals to compare if theres a road between
         * compared- the list of hospitals with roads between them
         * */
        private bool IfRoadDoesntExist(Point one, Point two, List<Point> compared)
        {
            for (int i = 0; i < compared.Count; i = i + 2)
            {
                if (compared[i] == one)
                {
                    if (compared[i + 1] == two)
                    {
                        return false;
                    }
                }
                if (compared[i] == two)
                {
                    if(compared[i+1]==one)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public void hospitalClick(object sender, EventArgs e)
        {
            var btn = sender as Button;
            String name = btn.Text;
            Hospital hospital = new Hospital("Hospital Unknown",0,0,0);
            foreach(Hospital hosp in h)
            {
                if((hosp.getName() + " Hospital")== btn.Text)
                {
                    hospital = hosp;
                }
            }
            Form2 formo = new Form2(hospital);
            formo.Show();
            
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Dispose();
            killed = true;
            sim.kill();
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            sim.setSpeedTwo();
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            sim.setSpeedOne();
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            sim.pause();
        }

        private void LoadSettingsToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void printHosptialInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DbConnect dbConnect = new DbConnect();
            dbConnect.printHospitalToTerminal();
        }

        private void bloodTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Blood.get_blood_list();
            Blood.insert_blood(1, "A+", false);
        }

        public void Form1_Load(object sender, EventArgs e)
        {

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;
            killed = true;
            sim.kill();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
